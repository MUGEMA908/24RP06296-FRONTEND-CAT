document.getElementById("feedbackForm").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Thank you for your feedback!");
});function(e) {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const message = document.getElementById('message').value.trim();

  if (name && message) {
    alert("Feedback submitted successfully. Thank you!");
    this.reset();
  } else {
    alert("Please fill out all fields.");
  }
});